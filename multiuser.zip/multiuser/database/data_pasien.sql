-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 19 Jul 2024 pada 12.39
-- Versi server: 10.4.25-MariaDB
-- Versi PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data_pasien`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_pasien`
--

CREATE TABLE `data_pasien` (
  `tgllapor` date DEFAULT NULL,
  `daerah` varchar(255) DEFAULT NULL,
  `masuk` varchar(255) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `jk` varchar(10) DEFAULT NULL,
  `tgllahir` date DEFAULT NULL,
  `rmedis` int(11) NOT NULL,
  `bpjs` varchar(255) DEFAULT NULL,
  `nik` varchar(16) DEFAULT NULL,
  `katpasien` varchar(255) DEFAULT NULL,
  `jaminan` varchar(255) DEFAULT NULL,
  `nohp` varchar(15) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `diagmed` varchar(255) DEFAULT NULL,
  `diag` varchar(255) DEFAULT NULL,
  `riwayatpenyakit` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `data_pasien`
--

INSERT INTO `data_pasien` (`tgllapor`, `daerah`, `masuk`, `nama`, `jk`, `tgllahir`, `rmedis`, `bpjs`, `nik`, `katpasien`, `jaminan`, `nohp`, `alamat`, `diagmed`, `diag`, `riwayatpenyakit`) VALUES
('2024-07-17', 'Kabupaten Damasraya', 'Rujukan ke IGD', 'Jason Susanto', 'Laki-laki', '2001-08-29', 1763, '010524', '20478579461523', 'Baru', 'UMUM', '087712128569', 'JL. Mawar No. 09', 'Gangguan Mental Organik', 'Harga Diri Rendah', 'Vertigo'),
('2024-07-04', 'Kota Sawahlunto', 'Rujukan ke Rawat Jalan', 'Rachmat Iqbal', 'Laki-laki', '2002-05-22', 4444, '225874', '1100458456871479', 'Lama', 'PT. Bukit Asam', '087896542589', 'JL. Kenangan No. 9', 'Psikotik Akut', 'Waham', 'Gastritis'),
('2024-07-15', 'Kabupaten Solok', 'Rujukan ke IGD', 'Azzahra Amalia Putri Harryani', 'Perempuan', '2003-09-09', 5234, '123456', '3160594845033387', 'Baru', 'BPJS PNS', '086623461186', 'JL. Kartini No. 10', 'Skizofrenia Paranoid', 'Halusinasi', 'Vertigo'),
('2024-07-01', 'Kabupaten Sijunjung', 'Rujukan ke Rawat Jalan', 'Aaron Leonhart', 'Laki-laki', '1996-12-17', 5496, '012548', '4520789458217728', 'Lama', 'BAZNAS', '087746511010', 'JL. Kedoya No. 142', 'Skizo Afektif', 'Gangguan Komunikasi Verbal', 'Hipertensi');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `data_pasien`
--
ALTER TABLE `data_pasien`
  ADD PRIMARY KEY (`rmedis`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `data_pasien`
--
ALTER TABLE `data_pasien`
  MODIFY `rmedis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2147483648;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
