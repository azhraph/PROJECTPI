<?php
include("header.php");

// Pastikan koneksi database ada
include("con_pasien.php");

// Cek apakah pengguna memiliki hak akses admin
if (!isset($_SESSION['admin_akses']) || !in_array("admin", $_SESSION['admin_akses'])) {
    echo "Kamu tidak punya akses.";
    include("footer.php");
    exit();
}

// Ambil ID yang akan dihapus dari query string
if (isset($_GET['deleteid'])) {
    $rmedis = $_GET['deleteid'];
    
    // Membuat query untuk menghapus data
    $sql = "DELETE FROM data_pasien WHERE rmedis = '$rmedis'";
    
    // Mengirim query ke database dan mengonfirmasi jika berhasil
    if (mysqli_query($con, $sql)) {
        echo "<p>Data berhasil dihapus!</p>";
    } else {
        echo "<p>Error: " . mysqli_error($con) . "</p>";
    }
}

// Menutup koneksi
mysqli_close($con);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hapus Data Pasien</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
    <div class="container my-5">
      <button class="add"><a href="admin.php" class="text-light">Kembali ke Halaman Data Pasien</a></button>
    </div>
  </body>
</html>

<?php include("footer.php"); ?>
