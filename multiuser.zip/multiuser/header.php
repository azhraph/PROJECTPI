<?php
session_start();
include("con_user.php");
if (!isset($_SESSION['admin_username'])) {
    header("location:masuk.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIstem Pendataan Pasien Psikiatri</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <nav class="navbar">
        <div class="marquee">
            <span>Selamat Datang di Sistem Pendataan Pasien Psikiatri RSUD M. Natsir</span>
        </div>
    </nav>
    <div class="navbar-left">
        <img src="img/logo.png" alt="RSUD M. Natsir Logo" class="logo">
        <a>Layanan Pengaduan: 0822 1145 8984</a>
    </div>
    <div class="home">
        <nav>
            <ul>
                <li><a href="beranda.php">Beranda</a></li>
                <?php if (in_array("pegawai", $_SESSION['admin_akses'])) { ?>
                <li><a href="pendataan.php">Pendataan</a></li>
                <?php } ?>
                <?php if (in_array("admin", $_SESSION['admin_akses'])) { ?>
                <li><a href="admin.php">Data Pasien</a></li>
                <?php } ?>
                <li><a href="keluar.php">Keluar >></a></li>
            </ul>
        </nav>
    </div>
</body>
