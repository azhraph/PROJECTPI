<?php
include("header.php");
if (!in_array("pegawai", $_SESSION['admin_akses'])) {
    echo "Kamu tidak punya akses";
    include("footer.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <h1>Sistem Pendataan Pasien Psikiatri</h1>
    <p><img src="img/home.png"></p>
    <h4>Anda dapat melakukan penginputan data pasien dengan cara menekan button Tambahkan Data dibawah</h4>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <button class="add"><a href="input.php" class="text-light">Tambahkan Data</a></button>
</body>
    
<?php
include("footer.php");
?>