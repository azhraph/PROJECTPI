<?php
include("header.php");
?>
<?php
if (isset($_POST['submit'])) {
    $tgllapor = $_POST['tgllapor'];
    $daerah = $_POST['daerah'];
    $masuk = $_POST['masuk'];
    $nama = $_POST['nama'];
    $jk = $_POST['jk'];
    $tgllahir = $_POST['tgllahir'];
    $rmedis = $_POST['rmedis'];
    $bpjs = $_POST['bpjs'];
    $nik = $_POST['nik'];
    $katpasien = $_POST['katpasien'];
    $jaminan = $_POST['jaminan'];
    $nohp = $_POST['nohp'];
    $alamat = $_POST['alamat'];
    $diagmed = $_POST['diagmed'];
    $diag = $_POST['diag'];
    $riwayatpenyakit = $_POST['riwayatpenyakit'];

    // Detail database
    $db_host = "localhost";
    $db_user = "root";
    $db_pass = "";
    $db_name = "data_pasien";

    // Membuat koneksi
    $con = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

    if (!$con) {
        die("Koneksi Gagal");
    }

    // Menggunakan SQL untuk membuat query data entry
    $sql = "INSERT INTO data_pasien (tgllapor, daerah, masuk, nama, jk, tgllahir, rmedis, bpjs, nik, katpasien, jaminan, nohp, alamat, diagmed, diag) VALUES ('$tgllapor', '$daerah', '$masuk', '$nama', '$jk', '$tgllahir', '$rmedis', '$bpjs', '$nik', '$katpasien', '$jaminan', '$nohp', '$alamat', '$diagmed', '$diag')";

    // Mengirim query ke database untuk menambahkan nilai dan mengonfirmasi jika berhasil
    $rs = mysqli_query($con, $sql);
    if ($rs) {
        echo "Data berhasil ditambahkan!";
    } else {
        echo "Error: " . mysqli_error($con);
    }

    // Menutup koneksi
    mysqli_close($con);
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">

    <title>Tambah Data Pasien</title>
  </head>

  <body>
    <div class="container my-5">
    <h2>Tambahkan Data Pasien</h2>
      <form method="post">

      <div class="form-group">
        <label>Tanggal Pelaporan</label>
        <input type="date" class="form-control" name="tgllapor">
      </div><br/>

      <div class="form-group">
        <label>Asal Daerah</label> <br/>
        <select name="daerah" class="form-control">
          <option value="">--</option>
          <option value="Kota Solok">Kota Solok</option>
          <option value="Kabupaten Solok">Kabupaten Solok</option>
          <option value="Kota Sawahlunto">Kota Sawahlunto</option>
          <option value="Kabupaten Sijunjung">Kabupaten Sijunjung</option>
          <option value="Kabupaten Damasraya">Kabupaten Damasraya</option>
          <option value="Lain-lain">Lain-lain</option>
        </select>
      </div><br/>

      <div class="form-group">
      <label>Jalur Masuk</label>
        <select name="masuk" class="form-control">
          <option value="">--</option>
          <option value="Rujukan ke Rawat Jalan">Rujukan ke Rawat Jalan</option>
          <option value="Rujukan ke IGD">Rujukan ke IGD</option>
          <option value="IGD tanpa Rujukan">IGD tanpa Rujukan</option>
        </select>
      </div><br/>

      <div class="form-group">
        <label>Nama</label>
        <input type="text" class="form-control" placeholder="Masukkan Nama Lengkap" name="nama">
      </div><br/>
        
      <div class="form-group">
        <label>Jenis Kelamin</label>
        <select name="jk" class="form-control">
          <option value="">--</option>
          <option value="Laki-laki">Laki-laki</option>
          <option value="Perempuan">Perempuan</option>
      </select>
      </div><br/>

      <div class="form-group">
        <label>Tanggal Lahir</label>
        <input type="date" class="form-control" name="tgllahir">
      </div><br/>

      <div class="form-group">
        <label>No. Rekam Medis</label>
        <input type="text" class="form-control" placeholder="Masukkan No. Rekam Medis" name="rmedis">
      </div><br/>

      <div class="form-group">
        <label>No. BPJS</label>
        <input type="text" class="form-control" placeholder="Masukkan No. BPJS" name="bpjs">
      </div><br/>

      <div class="form-group">
        <label>NIK</label>
        <input type="text" class="form-control" placeholder="Masukkan NIK" name="nik">
      </div><br/>

      <div class="form-group">
        <label>Kategori Pasien</label>
        <select name="katpasien" class="form-control">
          <option value="">--</option>
          <option value="Baru">Baru</option>
          <option value="Lama">Lama</option>
        </select>
      </div><br/>

      <div class="form-group">
        <label>Jaminan Kesehatan</label>
        <select name="jaminan" class="form-control">
          <option value="">--</option>
          <option value="BPJS PBI">BPJS PBI</option>
          <option value="BPJS Mandiri">BPJS Mandiri</option>
          <option value="BPJS PNS">BPJS PNS</option>
          <option value="PT. Bukit Asam">PT. Bukit Asam</option>
          <option value="BAZNAS">BAZNAS</option>
          <option value="Dana Pendamping">Dana Pendamping</option>
          <option value="PJKA">PJKA</option>
          <option value="UMUM">UMUM</option>
          <option value="Lain-lain">Lain-lain</option>
        </select>
      </div><br/>

      <div class="form-group">
        <label>No. HP/WA Keluarga</label>
        <input type="text" class="form-control" placeholder="Masukkan No. HP/WA Keluarga yang aktif" name="nohp">
      </div><br/>

      <div class="form-group">
        <label>Alamat</label>
        <input type="text" class="form-control" placeholder="Masukkan Alamat" name="alamat">
      </div><br/>

      <div class="form-group">
        <label>Diagnosa Medis</label>
        <select name="diagmed" class="form-control">
          <option value="">--</option>
          <option value="Skizofrenia Paranoid">Skizofrenia Paranoid</option>
          <option value="Dimensia">Dimensia</option>
          <option value="Skizo Afektif">Skizo Afektif</option>
          <option value="Gangguan Mental Organik">Gangguan Mental Organik</option>
          <option value="Psikotik Akut">Psikotik Akut</option>
          <option value="Lain-lain">Lain-lain</option>
        </select>
      </div><br/>

      <div class="form-group">
        <label>Diagnosa Keperawatan</label>
        <select name="diag" class="form-control">
          <option value="">--</option>
          <option value="Halusinasi">Halusinasi</option>
          <option value="Resiko Perilaku Kekerasan">Resiko Perilaku Kekerasan</option>
          <option value="Harga Diri Rendah">Harga Diri Rendah</option>
          <option value="Defisit Perawatan Diri">Defisit Perawatan Diri</option>
          <option value="Waham">Waham</option>
          <option value="Resiko Bunuh Diri">Resiko Bunuh Diri</option>
          <option value="Gangguan Komunikasi Verbal">Gangguan Komunikasi Verbal</option>
          <option value="Ketidakefektifan Pemeliharaan Kesehatan">Ketidakefektifan Pemeliharaan Kesehatan</option>
          <option value="Lain-lain">Lain-lain</option>
        </select>
      </div><br/>

      <div class="form-group">
        <label>Riwayat Penyakit Dahulu</label>
        <input type="text" class="form-control" placeholder="Masukkan Riwayat Penyakit Dahulu" name="riwayatpenyakit">
      </div><br/>
   
      <button type="submit" class="btn btn-primary my-5" name="submit">Kirim</button>
    </div>
  </body>
</html>

<?php
include("footer.php");
?>