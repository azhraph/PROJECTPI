<?php
include("header.php");

// Pastikan koneksi database ada
include("con_pasien.php");

// Cek apakah pengguna memiliki hak akses admin
if (!isset($_SESSION['admin_akses']) || !in_array("admin", $_SESSION['admin_akses'])) {
    echo "Kamu tidak punya akses.";
    include("footer.php");
    exit();
}

// Tampilkan data pasien
$sql = "SELECT tgllapor, rmedis, nama, jk, tgllahir, diag FROM data_pasien ORDER BY tgllapor ASC";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Pendataan Pasien Psikiatri</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>

<body style='background-image: url("/img/bg.jpg")'>
    <h1>Sistem Pendataan Pasien Psikiatri</h1>
    <p><img src="img/home.png"></p>

    <button class="add"><a href="input.php" class="text-light">Tambahkan Data</a></button>
    <div class="container">
        <h4>Data-data Pasien Psikiatri</h4>
        <table class="table table-dark table-hover">
            <thead>
                <tr>
                    <th scope="col" style="color: white">Tanggal Pelaporan</th>
                    <th scope="col" style="color: white">No. Rekam Medis</th>
                    <th scope="col" style="color: white">Nama</th>
                    <th scope="col" style="color: white">Jenis Kelamin</th>
                    <th scope="col" style="color: white">Tanggal Lahir</th>
                    <th scope="col" style="color: white">Diagnosa Keperawatan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo '<tr>
                            <td style="color: white">' . $row['tgllapor'] . '</td>
                            <td style="color: white">' . $row['rmedis'] . '</td>
                            <td style="color: white">' . $row['nama'] . '</td>
                            <td style="color: white">' . $row['jk'] . '</td>
                            <td style="color: white">' . $row['tgllahir'] . '</td>
                            <td style="color: white">' . $row['diag'] . '</td>
                            <td style="color: white">
                                <button class="btn btn-primary"><a href="edit.php?updateid=' . $row['rmedis'] . '" class="text-light">Edit</a></button>
                                <button class="btn btn-primary"><a href="cetak.php?updateid=' . $row['rmedis'] . '" class="text-light">Cetak</a></button>
                                <button class="btn btn-danger"><a href="hapus.php?deleteid=' . $row['rmedis'] . '" class="text-light">Hapus</a></button>
                            </td>
                        </tr>';
                    }
                } else {
                    echo '<tr><td colspan="16">Error: ' . mysqli_error($con) . '</td></tr>';
                }

                mysqli_close($con);
                ?>
            </tbody>
        </table>
    </div>
</body>

<?php
include("footer.php");
?>
