<footer class="text-center mt-5">
    <p>&copy; 2024 RSUD M. Natsir. All rights reserved.</p>
    <p>Developed by Azzahra Amalia Putri Harryani.</p>
</footer>
</html>
