<?php
include("header.php");

// Pastikan koneksi database ada
include 'con_pasien.php';

// Cek apakah pengguna memiliki hak akses admin
if (!isset($_SESSION['admin_akses']) || !in_array("admin", $_SESSION['admin_akses'])) {
    echo "Kamu tidak punya akses.";
    include("footer.php");
    exit();
}

// Menampilkan error PHP untuk debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Ambil data pasien berdasarkan rmedis
$rmedis = isset($_GET['updateid']) ? mysqli_real_escape_string($con, $_GET['updateid']) : '';

if ($rmedis) {
    $sql = "SELECT * FROM data_pasien WHERE rmedis=?";
    $stmt = mysqli_prepare($con, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 's', $rmedis);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $data = mysqli_fetch_assoc($result);

        // Periksa apakah data ditemukan
        if (!$data) {
            echo "Data tidak ditemukan.";
            include("footer.php");
            exit();
        }
        
        // Isi formulir dengan data yang ada
        $tgllapor = htmlspecialchars($data['tgllapor']);
        $daerah = htmlspecialchars($data['daerah']);
        $masuk = htmlspecialchars($data['masuk']);
        $nama = htmlspecialchars($data['nama']);
        $jk = htmlspecialchars($data['jk']);
        $tgllahir = htmlspecialchars($data['tgllahir']);
        $bpjs = htmlspecialchars($data['bpjs']);
        $nik = htmlspecialchars($data['nik']);
        $katpasien = htmlspecialchars($data['katpasien']);
        $jaminan = htmlspecialchars($data['jaminan']);
        $nohp = htmlspecialchars($data['nohp']);
        $alamat = htmlspecialchars($data['alamat']);
        $diagmed = htmlspecialchars($data['diagmed']);
        $diag = htmlspecialchars($data['diag']);
        $riwayatpenyakit = htmlspecialchars($data['riwayatpenyakit']);

        mysqli_stmt_close($stmt);
    } else {
        echo "Gagal menyiapkan query: " . mysqli_error($con);
    }
} else {
    echo "ID pasien tidak ditemukan.";
    include("footer.php");
    exit();
}

// Proses pembaruan data
if (isset($_POST['submit'])) {
    $tgllapor = $_POST['tgllapor'];
    $daerah = $_POST['daerah'];
    $masuk = $_POST['masuk'];
    $nama = $_POST['nama'];
    $jk = $_POST['jk'];
    $tgllahir = $_POST['tgllahir'];
    $bpjs = $_POST['bpjs'];
    $nik = $_POST['nik'];
    $katpasien = $_POST['katpasien'];
    $jaminan = $_POST['jaminan'];
    $nohp = $_POST['nohp'];
    $alamat = $_POST['alamat'];
    $diagmed = $_POST['diagmed'];
    $diag = $_POST['diag'];
    $riwayatpenyakit = $_POST['riwayatpenyakit'];

    $update_sql = "UPDATE data_pasien SET tgllapor=?, daerah=?, masuk=?, nama=?, jk=?, tgllahir=?, bpjs=?, nik=?, katpasien=?, jaminan=?, nohp=?, alamat=?, diagmed=?, diag=?, riwayatpenyakit=? WHERE rmedis=?";
    $update_stmt = mysqli_prepare($con, $update_sql);

    if ($update_stmt) {
        mysqli_stmt_bind_param($update_stmt, 'ssssssssssssssss', $tgllapor, $daerah, $masuk, $nama, $jk, $tgllahir, $bpjs, $nik, $katpasien, $jaminan, $nohp, $alamat, $diagmed, $diag, $riwayatpenyakit, $rmedis);
        $result = mysqli_stmt_execute($update_stmt);

        if ($result) {
            echo "Data berhasil diperbarui!";
            header('Location: admin.php');
            exit();
        } else {
            echo "Gagal memperbarui data: " . mysqli_error($con);
        }

        mysqli_stmt_close($update_stmt);
    } else {
        echo "Gagal menyiapkan query: " . mysqli_error($con);
    }
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Edit Data Pasien</title>
  </head>
  <body>
    <div class="container my-5">
      <h2>Edit Data Pasien</h2>
      <form method="post">
        <div class="form-group">
            <label>Tanggal Pelaporan</label>
            <input type="date" class="form-control" name="tgllapor" value="<?php echo $tgllapor; ?>">
        </div><br/>

        <div class="form-group">
          <label>Asal Daerah</label> <br/>
          <select name="daerah" class="form-control">
            <option value="">--</option>
            <option value="Kota Solok" <?php if ($daerah == 'Kota Solok') echo 'selected'; ?>>Kota Solok</option>
            <option value="Kabupaten Solo" <?php if ($daerah == 'Kabupaten Solo') echo 'selected'; ?>>Kabupaten Solok</option>
            <option value="Kota Sawahlunto" <?php if ($daerah == 'Kota Sawahlunto') echo 'selected'; ?>>Kota Sawahlunto</option>
            <option value="Kabupaten Sijunjung" <?php if ($daerah == 'Kabupaten Sijunjung') echo 'selected'; ?>>Kabupaten Sijunjung</option>
            <option value="Kabupaten Damasraya" <?php if ($daerah == 'Kabupaten Damasraya') echo 'selected'; ?>>Kabupaten Damasraya</option>
            <option value="Lain-lain" <?php if ($daerah == 'Lain-lain') echo 'selected'; ?>>Lain-lain</option>
          </select>
        </div><br/>

        <div class="form-group">
        <label>Jalur Masuk</label>
          <select name="masuk" class="form-control">
            <option value="">--</option>
            <option value="Rujukan ke Rawat Jalan" <?php if ($masuk == 'Rujukan ke Rawat Jalan') echo 'selected'; ?>>Rujukan ke Rawat Jalan</option>
            <option value="Rujukan ke IGD" <?php if ($masuk == 'Rujukan ke IGD') echo 'selected'; ?>>Rujukan ke IGD</option>
            <option value="IGD tanpa Rujukan" <?php if ($masuk == 'IGD tanpa Rujukan') echo 'selected'; ?>>IGD tanpa Rujukan</option>
          </select>
        </div><br/>

        <div class="form-group">
          <label>Nama</label>
          <input type="text" class="form-control" placeholder="Masukkan Nama Lengkap" name="nama" value="<?php echo $nama; ?>">
        </div><br/>

        <div class="form-group">
          <label>Jenis Kelamin</label>
          <select name="jk" class="form-control">
            <option value="">--</option>
            <option value="Laki-laki" <?php if ($jk == 'Laki-laki') echo 'selected'; ?>>Laki-laki</option>
            <option value="Perempuan" <?php if ($jk == 'Perempuan') echo 'selected'; ?>>Perempuan</option>
        </select>
        </div><br/>

        <div class="form-group">
          <label>Tanggal Lahir</label>
          <input type="date" class="form-control" name="tgllahir" value="<?php echo $tgllahir; ?>">
        </div><br/>

        <div class="form-group">
          <label>No. Rekam Medis</label>
          <input type="text" class="form-control" placeholder="Masukkan No. Rekam Medis" name="rmedis" value="<?php echo $rmedis; ?>" readonly>
        </div><br/>

        <div class="form-group">
          <label>No. BPJS</label>
          <input type="text" class="form-control" placeholder="Masukkan No. BPJS" name="bpjs" value="<?php echo $bpjs; ?>">
        </div><br/>

        <div class="form-group">
          <label>NIK</label>
          <input type="text" class="form-control" placeholder="Masukkan NIK" name="nik" value="<?php echo $nik; ?>">
        </div><br/>

        <div class="form-group">
          <label>Kategori Pasien</label>
          <select name="katpasien" class="form-control">
            <option value="">--</option>
            <option value="Baru" <?php if ($katpasien == 'Baru') echo 'selected'; ?>>Baru</option>
            <option value="Lama" <?php if ($katpasien == 'Lama') echo 'selected'; ?>>Lama</option>
          </select>
        </div><br/>

        <div class="form-group">
          <label>Jaminan Kesehatan</label>
          <select name="jaminan" class="form-control">
            <option value="">--</option>
            <option value="BPJS PBI" <?php if ($jaminan == 'BPJS PBI') echo 'selected'; ?>>BPJS PBI</option>
            <option value="BPJS Mandiri" <?php if ($jaminan == 'BPJS Mandiri') echo 'selected'; ?>>BPJS Mandiri</option>
            <option value="BPJS PNS" <?php if ($jaminan == 'BPJS PNS') echo 'selected'; ?>>BPJS PNS</option>
            <option value="PT. Bukit Asam" <?php if ($jaminan == 'PT. Bukit Asam') echo 'selected'; ?>>PT. Bukit Asam</option>
            <option value="BAZNAS" <?php if ($jaminan == 'BAZNAS') echo 'selected'; ?>>BAZNAS</option>
            <option value="Dana Pendamping" <?php if ($jaminan == 'Dana Pendamping') echo 'selected'; ?>>Dana Pendamping</option>
            <option value="PJKA" <?php if ($jaminan == 'PJKA') echo 'selected'; ?>>PJKA</option>
            <option value="UMUM" <?php if ($jaminan == 'UMUM') echo 'selected'; ?>>UMUM</option>
            <option value="Lain-lain" <?php if ($jaminan == 'Lain-lain') echo 'selected'; ?>>Lain-lain</option>
          </select>
        </div><br/>

        <div class="form-group">
          <label>No. HP/WA Keluarga</label>
          <input type="text" class="form-control" placeholder="Masukkan No. HP/WA Keluarga yang aktif" name="nohp" value="<?php echo $nohp; ?>">
        </div><br/>

        <div class="form-group">
          <label>Alamat</label>
          <input type="text" class="form-control" placeholder="Masukkan Alamat" name="alamat" value="<?php echo $alamat; ?>">
        </div><br/>

        <div class="form-group">
          <label>Diagnosa Medis</label>
          <input type="text" class="form-control" placeholder="Masukkan Diagnosa Medis" name="diagmed" value="<?php echo $diagmed; ?>">
        </div><br/>

        <div class="form-group">
          <label>Diagnosa Keperawatan</label>
          <select name="diag" class="form-control">
            <option value="">--</option>
            <option value="Halusinasi" <?php if ($diag == 'Halusinasi') echo 'selected'; ?>>Halusinasi</option>
            <option value="Resiko Perilaku Kekerasan" <?php if ($diag == 'Resiko Perilaku Kekerasan') echo 'selected'; ?>>Resiko Perilaku Kekerasan</option>
            <option value="Harga Diri Rendah" <?php if ($diag == 'Harga Diri Rendah') echo 'selected'; ?>>Harga Diri Rendah</option>
            <option value="Defisit Perawatan Diri" <?php if ($diag == 'Defisit Perawatan Diri') echo 'selected'; ?>>Defisit Perawatan Diri</option>
            <option value="Waham" <?php if ($diag == 'Waham') echo 'selected'; ?>>Waham</option>
            <option value="Resiko Bunuh Diri" <?php if ($diag == 'Resiko Bunuh Diri') echo 'selected'; ?>>Resiko Bunuh Diri</option>
            <option value="Gangguan Komunikasi Verbal" <?php if ($diag == 'Gangguan Komunikasi Verbal') echo 'selected'; ?>>Gangguan Komunikasi Verbal</option>
            <option value="Ketidakefektifan Pemeliharaan Kesehatan" <?php if ($diag == 'Ketidakefektifan Pemeliharaan Kesehatan') echo 'selected'; ?>>Ketidakefektifan Pemeliharaan Kesehatan</option>
            <option value="Lain-lain" <?php if ($diag == 'Lain-lain') echo 'selected'; ?>>Lain-lain</option>
          </select>
        </div><br/>

        <div class="form-group">
          <label>Riwayat Penyakit Dahulu</label>
          <input type="text" class="form-control" placeholder="Masukkan Riwayat Penyakit Dahulu" name="riwayatpenyakit" value="<?php echo $riwayatpenyakit; ?>">
        </div><br/>

        <button type="submit" class="btn btn-primary my-5" name="submit">Edit</button>
      </form>
    </div>
  </body>

<?php
include("footer.php");
?>
