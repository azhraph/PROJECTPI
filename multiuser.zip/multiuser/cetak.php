<?php
include("header.php");

// Pastikan koneksi database ada
include 'con_pasien.php';

// Cek apakah pengguna memiliki hak akses admin
if (!isset($_SESSION['admin_akses']) || !in_array("admin", $_SESSION['admin_akses'])) {
    echo "Kamu tidak punya akses.";
    include("footer.php");
    exit();
}

// Ambil data pasien berdasarkan rmedis
$rmedis = isset($_GET['updateid']) ? mysqli_real_escape_string($con, $_GET['updateid']) : '';

if ($rmedis) {
    $sql = "SELECT * FROM data_pasien WHERE rmedis=?";
    $stmt = mysqli_prepare($con, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 's', $rmedis);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $data = mysqli_fetch_assoc($result);

        // Periksa apakah data ditemukan
        if (!$data) {
            echo "Data tidak ditemukan.";
            include("footer.php");
            exit();
        }
        
        // Isi variabel dengan data yang ada
        $tgllapor = htmlspecialchars($data['tgllapor']);
        $daerah = htmlspecialchars($data['daerah']);
        $masuk = htmlspecialchars($data['masuk']);
        $nama = htmlspecialchars($data['nama']);
        $jk = htmlspecialchars($data['jk']);
        $tgllahir = htmlspecialchars($data['tgllahir']);
        $bpjs = htmlspecialchars($data['bpjs']);
        $nik = htmlspecialchars($data['nik']);
        $katpasien = htmlspecialchars($data['katpasien']);
        $jaminan = htmlspecialchars($data['jaminan']);
        $nohp = htmlspecialchars($data['nohp']);
        $alamat = htmlspecialchars($data['alamat']);
        $diagmed = htmlspecialchars($data['diagmed']);
        $diag = htmlspecialchars($data['diag']);
        $riwayatpenyakit = htmlspecialchars($data['riwayatpenyakit']);

        mysqli_stmt_close($stmt);
    } else {
        echo "Gagal menyiapkan query: " . mysqli_error($con);
    }
} else {
    echo "ID pasien tidak ditemukan.";
    include("footer.php");
    exit();
}

?>

<!doctype html>
<html lang="id">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Cetak Pelaporan Data Pasien</title>
    <style>
        @media print {
            .navbar, .home, .btn {
                display: none !important;
            }
            .container {
                margin-top: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container my-5">
        <h2 class="text-center">Pelaporan Data Pasien</h2>
        <table class="table table-bordered">
            <tr>
                <th>Tanggal Pelaporan</th>
                <td><?php echo $tgllapor; ?></td>
            </tr>
            <tr>
                <th>No. Rekam Medis</th>
                <td><?php echo $rmedis; ?></td>
            </tr>
            <tr>
                <th>Nama</th>
                <td><?php echo $nama; ?></td>
            </tr>
            <tr>
                <th>Jenis Kelamin</th>
                <td><?php echo $jk; ?></td>
            </tr>
            <tr>
                <th>Tanggal Lahir</th>
                <td><?php echo $tgllahir; ?></td>
            </tr>
            <tr>
                <th>Asal Daerah</th>
                <td><?php echo $daerah; ?></td>
            </tr>
            <tr>
                <th>Jalur Masuk</th>
                <td><?php echo $masuk; ?></td>
            </tr>
            <tr>
                <th>No. BPJS</th>
                <td><?php echo $bpjs; ?></td>
            </tr>
            <tr>
                <th>NIK</th>
                <td><?php echo $nik; ?></td>
            </tr>
            <tr>
                <th>Kategori Pasien</th>
                <td><?php echo $katpasien; ?></td>
            </tr>
            <tr>
                <th>Jaminan Kesehatan</th>
                <td><?php echo $jaminan; ?></td>
            </tr>
            <tr>
                <th>No. HP/WA Keluarga</th>
                <td><?php echo $nohp; ?></td>
            </tr>
            <tr>
                <th>Alamat</th>
                <td><?php echo $alamat; ?></td>
            </tr>
            <tr>
                <th>Diagnosa Medis</th>
                <td><?php echo $diagmed; ?></td>
            </tr>
            <tr>
                <th>Diagnosa Keperawatan</th>
                <td><?php echo $diag; ?></td>
            </tr>
            <tr>
                <th>Riwayat Penyakit Dahulu</th>
                <td><?php echo $riwayatpenyakit; ?></td>
            </tr>
        </table>
        <button onclick="window.print()" class="btn btn-primary">Cetak</button>
        <button class="btn btn-secondary"><a href="admin.php" class="text-light">Kembali ke Halaman Data Pasien</a></button>
    </div>
</body>
</html>
<?php
include("footer.php");
?>