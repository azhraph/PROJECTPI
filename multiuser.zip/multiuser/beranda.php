<?php
include("header.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <h1>Sistem Pendataan Pasien Psikiatri</h1>
    <p><img src="img/home.png"></p>
    <h4>Silakan lakukan penginputan Data Pasien pada bagian Pendataan</h4>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>

<?php
include("footer.php");
?>